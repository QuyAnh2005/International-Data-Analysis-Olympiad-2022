export PATH=/usr/conda/bin:$PATH
python generate_submission.py
